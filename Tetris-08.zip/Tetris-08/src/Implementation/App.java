package Implementation; 
import java.util.Random;
import GUI.UI;
//import GUI.UI;

public class App {
    private static int[][] field = new int[5][15];
    public static UI ui = new UI(5, 15, 50);
    public static Pentominoe pentominoe;
    public static boolean checkidkwhat = true;
    public static boolean booleanBot = true;
    


    public static void PlayUser(){
       
    
        while (true) {
            Random rand = new Random();
            pentominoe = new Pentominoe(rand.nextInt(12));
    
            Tetris.addPiece(field, pentominoe, 0, 0);
    
            for (int i = 0; i < field[0].length; i++) {
                for (int j = 0; j < field.length; j++) {
                    System.out.print(field[j][i] + "  ");
                }
                System.out.println(" ");
            }
            System.out.println(" ");

            Tetris.pieceMoveDown(field, pentominoe, 0, 0);
            for(int i = 0; i < field.length; i++) {
                for (int j = 0; j < field[0].length; j++) {
                    System.out.print(field[i][j] + "  ");
                }
                System.out.println("");
            }
            System.out.println(" ");
        }
        
    }
    

    
    public static void main(String[] args) throws Exception {
        while(checkidkwhat && booleanBot){
            System.out.println("IN WHILE");
            continue;
        }
        System.out.println("WAARNING");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 15; j++) {
                field[i][j] = -1;
            }
        }

        //if(checkidwhat) then playUser
        //else if(booleanBot) then playBot
        /*Pour bot, creer une autre boolean et verifier si boolean bot + boolean user */
        if(!checkidkwhat){
        PlayUser();
        }
        if(!booleanBot){
            Bot.initBot(ui);
        } 
      
    }
}


