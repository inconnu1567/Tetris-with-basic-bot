package Implementation;

import java.lang.Thread;
import java.util.Arrays;
import GUI.UI;

public class Tetris {
    static int[] position = new int[2]; // store the position of the piece for y and x
    public static boolean Down = false; //
    public static boolean Right = false; //
    public static boolean Left = false; //
    public static boolean Rotate = false; //
    public static boolean PauseClicked = false;

    /**
     * 
     * @return
     */
    public static int GetXPosition() {
        return position[0];
    }

    /**
     * 
     * @return
     */
    public static int GetYPosition() {
        return position[1];
    }

    /**
     * Adds a new piece to the board.
     * 
     * @param gameBoard  -
     * @param pentominoe -
     * @param x          -
     * @param y          -
     * @throws InterruptedException
     */
    public static void addPiece(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {
        if (!Tetris.checkIfFit(gameBoard, pentominoe, 0, 0)) {
            System.out.println("Game over !");
            // If game over, terminate the program(System.exit(0) means that we expected the
            // program to end)
            System.exit(0);
        }

        int[][] piece = pentominoe.getRepresentation();

        for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1) {
                    // Add the ID of the pentomino to the board if the pentomino occupies this
                    // square
                    gameBoard[x + j][y + i] = pentominoe.getID() + 1;
                }
            }
        }

        App.ui.setState(gameBoard);
        position[0] = x;
        position[1] = y;

        try {
            // it will sleep the main thread for 1 sec
            // ,each time the for loop runs
            Thread.sleep(500);
        } catch (Exception e) {
            // catching the exception
            System.out.println(e);
        }

        while(PauseClicked){
            System.out.println("pause");
            continue;//Va a la prochaine iteration et reviens au debut de la boucle, jusqu'a ce qu'on change la valeur de PauseClicked

        }
    
    }
    /**
     * Checks if the pentominoe fits in the board.
     * 
     * @param gameBoard
     * @param piece
     * @param x
     * @param y
     * @return
     */
    public static boolean checkIfFit(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {
        int[][] piece = pentominoe.getRepresentation();

        for (int i = 0; i < piece.length; i++) { // loop over y position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over x position of pentomino
                if (piece[i][j] == 1 && (x + j >= gameBoard.length || y + i >= gameBoard[0].length
                        || gameBoard[x + j][y + i] != -1)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Removes a piece from it's current position.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     */
    public static void removePiece(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {
        int[][] piece = pentominoe.getRepresentation();

        for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1) {
                    // Add the ID of the pentomino to the board if the pentomino occupies this
                    // square
                    gameBoard[x + j][y + i] = -1;
                }
            }
        }
    }

    /**
     * Checks if a line in the board is full.
     * 
     * @param gameBoard - the current game board
     * @param index     - index of the line that is checked
     * @return 'true' if it's full, 'false' if it's not full
     */
    public static boolean horizontalLineFull(int[][] gameBoard, int index) {
        int[] arr = { gameBoard[0][index], gameBoard[1][index], gameBoard[2][index], gameBoard[3][index],
                gameBoard[4][index] };// because board made out of 5 vertical arrays

        for (int j = 0; j < gameBoard.length; j++) {
            if (arr[j] == -1) {
                return false;
            }
        }

        return true;
    }

    /**
     * Checks if a line is full and deletes it.
     * 
     * @param gameBoard - the board
     * @param index     - index of the line that is checked
     * @return 'true' if a line was deleted and 'false' if the line wasn't deleted
     */
    public static boolean clearLine(int[][] gameBoard, int index) {
        System.out.println("Clear line");
        boolean check = horizontalLineFull(gameBoard, index);
        if (check) {
            System.out.println("horizontal filled");

            for (int j = 0; j < gameBoard.length; j++) {
                gameBoard[j][index] = -1;
            }
            
            for (int i = index; i > 0; i--) {
                for (int j = 0; j < gameBoard.length; j++) {
                    gameBoard[j][i] = gameBoard[j][i - 1];
                }
            }

            App.ui.updateScore();
            App.ui.setState(gameBoard);

        }

        return check;
    }

    public static int[][] lineClear(int[][] board) {
        for (int row = 0; row < board.length; row++) {
            if (horizontalLineFull(board, row)) {
                for (int j = 0; j < board.length; j++) {
                    board[j][row] = -1;
                }

                for (int i = row; i > 0; i--) {
                    for (int j = 0; j < board.length; j++) {
                        board[j][i] = board[j][i - 1];
                    }
                }
            }
        }
        return board;
    }

    /**
     * Checks if the space under the piece is empty.
     * 
     * @param gameBoard - the current board
     * @param piece     - matrix of the piece we want to check under
     * @param x         - upper left coordinate x of the pentominoe
     * @param y         - upper left coordinate y of the pentominoe
     * @return 'true' if there is an empty space under the piece, 'false' if there
     *         is another piece under it.
     */
    public static boolean checkEmptyUnder(int[][] gameBoard, int[][] piece, int x, int y) {

        for (int i = 0; i < piece.length; i++) {
            for (int j = 0; j < piece[0].length; j++) {
                System.out.print(piece[i][j]);

            }

            System.out.println();
        }
        // We start at the bottom part of each pentominoe, to see if its filled or not

        for (int j = 0; j < piece[piece.length - 1].length; j++) {
            int k = piece.length - 1;
            if ((piece[k][j] != 1)) {
                while (piece[k][j] != 1) {
                    System.out.print(k);
                    System.out.println(": k");
                    k--;
                }
            }

            if (gameBoard[x + j][y + k + 1] != -1) {
                System.out.print(k);
                System.out.println(": k");
                System.out.print(j);
                System.out.println(": j");
                System.out.println("not empty under");
                return false;

            }
        }

        System.out.println("empty under");
        return true;
    }

    /**
     * Moves the piece one square down.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     * @return
     */
    public static int[][] pieceMoveDown(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {

        int[][] piece = pentominoe.getRepresentation();
        int[][] newBoard = gameBoard;

        while ((y < gameBoard[0].length - piece.length) && checkEmptyUnder(gameBoard, piece, x, y)) {
            System.out.println("!!!!!");
            System.out.println(Down);
            System.out.println("!!!!!");
            
            if (Down) {
                y = pieceMoveStraightDown(newBoard, pentominoe, x, y);
                Down = false;
                continue;
            } else if (Right) {
                x = pieceMoveRight(newBoard, pentominoe, x, y);
                Right = false;
                continue;
            } else if (Left) {
                x = pieceMoveLeft(newBoard, pentominoe, x, y);
                Left = false;
                continue;
            } else if (Rotate) {
                pentominoe = pieceRotate(newBoard, pentominoe, x, y);
                Rotate = false;
                piece = pentominoe.getRepresentation();
                continue;
            }

            removePiece(newBoard, pentominoe, x, y);

            if ((y + 1) < gameBoard[0].length) {
                y++;
            }

            addPiece(newBoard, pentominoe, x, y);
            
            for (int i = 0; i < gameBoard[0].length; i++) {
                for (int j = 0; j < gameBoard.length; j++) {
                    System.out.print(gameBoard[j][i] + "  ");
                }

                System.out.println("");
            }

            System.out.println(" ");
        }

        for (int i = 0; i < piece.length; i++) {
            clearLine(gameBoard, y + piece.length - 1 - i);
        }

        return newBoard;
    }

    /**
     * Moves the piece straight down until it meets the end of the board or another
     * piece.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     * @return
     */
    public static int pieceMoveStraightDown(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {

        int[][] piece = pentominoe.getRepresentation();
        int[][] newBoard = gameBoard;

        removePiece(newBoard, pentominoe, x, y);
        while ((y < gameBoard[0].length - piece.length) && checkEmptyUnder(gameBoard, piece, x, y)) {
            if ((y + 1) < gameBoard[0].length) {
                y++;
            }

            System.out.println("PieceMoveStraightDown");
        }

        addPiece(newBoard, pentominoe, x, y);

        return y;
    }

    /**
     * Moves the piece one square to the left.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     * @return
     */
    public static int pieceMoveLeft(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {
        int[][] newBoard = gameBoard;

        removePiece(newBoard, pentominoe, x, y);
        if ((x > 0) && checkIfFit(gameBoard, pentominoe, x - 1, y)) {
            if ((x - 1) >= 0) {
                x--;
            }

            System.out.println("PieceMoveRight");
        }

        addPiece(newBoard, pentominoe, x, y);

        return x;
    }

    /**
     * Moves the piece one square to the right.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     * @return
     */
    public static int pieceMoveRight(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {

        int[][] piece = pentominoe.getRepresentation();
        int[][] newBoard = gameBoard;

        removePiece(newBoard, pentominoe, x, y);
        if ((x < gameBoard.length - piece[0].length) && checkIfFit(gameBoard, pentominoe, x + 1, y)) {
            if ((x + 1) < gameBoard.length) {
                x++;
            }

            System.out.println("PieceMoveRight");
        }

        addPiece(newBoard, pentominoe, x, y);

        return x;
    }

    /**
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     * @return
     */
    public static Pentominoe pieceRotate(int[][] gameBoard, Pentominoe pentominoe, int x, int y) {
        int[][] piece = pentominoe.rotate();
        System.out.println("IN ROTATE");
        int[][] newBoard = gameBoard;
        boolean piecefit = true;
        removePiece(newBoard, pentominoe, x, y);

       for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1 && (x + j >= gameBoard.length || y + i >= gameBoard[0].length
                        || gameBoard[x + j][y + i] != -1)) {
                    piecefit = false;
                }
            }
        }

        if (piecefit){
        int[][] tempPiece = pentominoe.updateForm(piece);
        if (Arrays.equals(piece, tempPiece)) {
            System.out.println("inside");
        }
    }
        
        

        addPiece(newBoard, pentominoe, x, y);

        return pentominoe;
    }
}
