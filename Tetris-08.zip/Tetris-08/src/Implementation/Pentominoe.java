package Implementation;

public class Pentominoe {
    private int[][] piece;
    private int pentID;
    // public int[][][]

    /**
     * Constructor for a pentominoe piece.
     * @param id - the ID of the pentominoe
     */
    public Pentominoe(int id) {
        pentID = id;
        if(id == 0) {
            // pentID = 0;
            piece = new int[3][3];
            piece[0][1] = 1;
            piece[1][0] = 1;
            piece[1][1] = 1;
            piece[1][2] = 1;
            piece[2][1] = 1;
            /*
            // pentomino representation X
                {0,1,0},
                {1,1,1},
                {0,1,0}
            */
        }
        if(id == 1) {
            piece = new int[5][1];
            piece[0][0] = 1;
            piece[1][0] = 1;
            piece[2][0] = 1;
            piece[3][0] = 1;
            piece[4][0] = 1;
            /*
            // pentomino representation I
                {1},
                {1},
                {1},
                {1},
                {1}
            */
        }
        if(id == 2) {
            piece = new int[3][3];
            piece[0][1] = 1;
            piece[0][2] = 1;
            piece[1][1] = 1;
            piece[2][0] = 1;
            piece[2][1] = 1;
            /*
            // pentomino representation Z
                {0,1,1},
                {0,1,0},
                {1,1,0}
            */
        }
        if(id == 3) {
            piece = new int[3][3];
            piece[0][0] = 1;
            piece[0][1] = 1;
            piece[0][2] = 1;
            piece[1][1] = 1;
            piece[2][1] = 1;
            /*
            // pentomino representation T
                {1,1,1},
                {0,1,0},
                {0,1,0}
            */
        }
        if(id == 4) {
            piece = new int[3][2];
            piece[0][0] = 1;
            piece[0][1] = 1;
            piece[1][0] = 1;
            piece[2][0] = 1;
            piece[2][1] = 1;
            /*
            // pentomino representation U
                {1,1},
                {1,0},
                {1,1}
            */
        }
        if(id == 5) {
            piece = new int[3][3];
            piece[0][0] = 1;
            piece[0][1] = 1;
            piece[0][2] = 1;
            piece[1][0] = 1;
            piece[2][0] = 1;
            /*
            // pentomino representation V
                {1,1,1},
                {1,0,0},
                {1,0,0}
            */
        }
        if(id == 6) {
            piece = new int[3][3];
            piece[0][2] = 1;
            piece[1][1] = 1;
            piece[1][2] = 1;
            piece[2][0] = 1;
            piece[2][1] = 1;
            /*
            // pentomino representation W
                {0,0,1},
                {0,1,1},
                {1,1,0}
            */
        }
        if(id == 7) {
            piece = new int[4][2];
            piece[0][0] = 1;
            piece[1][0] = 1;
            piece[1][1] = 1;
            piece[2][0] = 1;
            piece[3][0] = 1;
            /*
            // pentomino representation Y
                {1,0},
                {1,1},
                {1,0},
                {1,0}
            */
        }
        if(id == 8) {
            piece = new int[4][2];
            piece[0][0] = 1;
            piece[1][0] = 1;
            piece[2][0] = 1;
            piece[3][0] = 1;
            piece[3][1] = 1;
            /*
            // pentomino representation L
                {1,0},
                {1,0},
                {1,0},
                {1,1}
            */
        }
        if(id == 9) {
            piece = new int[3][2];
            piece[0][0] = 1;
            piece[0][1] = 1;
            piece[1][0] = 1;
            piece[1][1] = 1;
            piece[2][0] = 1;
            /*
            // pentomino representation P
                {1,1},
                {1,1},
                {1,0}
            */
        }
        if(id == 10) {
            piece = new int[2][4];
            piece[0][0] = 1;
            piece[0][1] = 1;
            piece[1][1] = 1;
            piece[1][2] = 1;
            piece[1][3] = 1;
            /*
            // pentomino representation N
                {1,1,0,0},
                {0,1,1,1}
            */
        }
        if(id == 11) {
            piece = new int[3][3];
            piece[0][1] = 1;
            piece[0][2] = 1;
            piece[1][0] = 1;
            piece[1][1] = 1;
            piece[2][1] = 1;
            /*
            // pentomino representation F
                {0,1,1},
                {1,1,0},
                {0,1,0}
            */
        }
    }

    /**
     * Getter for the matrix representing the pentominoe.
     * @return piece
     */
    public int[][] getRepresentation() {
        return piece;
    }

    /**
     * Getter for the ID of the pentominoe.
     * @return pentID
     */
    public int getID() {
        return pentID;
    }

    /**
     * Rotates the matrix once over 90 degrees to the right.
     * It does not make a copy, so the return matrix does not have to be used.
     * @return the rotated matrix
     */
    public int[][] rotate() {
        int[][] tempPiece = new int[piece[0].length][piece.length];
        //rotate it once and put it in tem7pPiece
        for (int i = 0; i < piece.length; i++) {
            for (int j = 0; j < piece[i].length; j++) {
                tempPiece[j][i] = piece[piece.length - i - 1][j];
            }
        }

        return tempPiece;
    }

    public int[][] updateForm(int[][] _piece){
        piece = _piece;
        return piece;
    }
}
