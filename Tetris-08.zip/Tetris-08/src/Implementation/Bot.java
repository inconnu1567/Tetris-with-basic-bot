package Implementation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import GUI.UI;

public class Bot {
    public static UI ui;
    public static double heightWeight = 5;
    public static double bumpinessWeight = 1;
    public static double holesWeight = 4;
    public static double lineClearWeight = 3;

    /**
     * Removes a piece from it's current position.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     */
    public static void removePiece(int[][] gameBoard, int[][] pentominoe, int x, int y) {
        int[][] piece = pentominoe;

        for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1) {
                    // Add the ID of the pentomino to the board if the pentomino occupies this
                    // square
                    gameBoard[x + j][y + i] = -1;
                }
            }
        }
    }

        /**
     * Moves the piece straight down until it meets the end of the board or another
     * piece.
     * 
     * @param gameBoard
     * @param pentominoe
     * @param x
     * @param y
     * @return
     */
    public static int[][] pieceMoveStraightDown(int[][] gameBoard, int[][] pentominoe, int x, int y) {

        int[][] piece = pentominoe;

        removePiece(gameBoard, pentominoe, x, y);
        while ((y < gameBoard[0].length - piece.length) && Tetris.checkEmptyUnder(gameBoard, piece, x, y)) {
            if ((y + 1) < gameBoard[0].length) {
                y++;
            }

            
        }

        addPiece(gameBoard, pentominoe, x, y);
        return gameBoard;
        
    }

    public static boolean checkIfFits(int[][] gameBoard, int[][] pentominoe, int x, int y) {
        int[][] piece = pentominoe;

        for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1 && (x + j >= gameBoard.length || y + i >= gameBoard[0].length || gameBoard[x + j][y + i] != -1 || x + j < 0 || y + i < 0)) {
                    return false;
                }
            }
        }

        return true;
    }


    /**
     * Checks if the pentominoe fits in the board.
     * 
     * @param gameBoard
     * @param piece
     * @param x
     * @param y
     * @return
     */
    public static boolean checkIfFit(int[][] gameBoard, int[][] pentominoe, int x, int y) {
        int[][] piece = pentominoe;

        for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1 && (x + j >= gameBoard.length || y + i >= gameBoard[0].length || gameBoard[x + j][y + i] != -1)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Adds a new piece to the board.
     * 
     * @param gameBoard  -
     * @param pentominoe -
     * @param x          -
     * @param y          -
     * @throws InterruptedException
     */
    public static int[][] addPiece(int[][] gameBoard, int[][] pentominoe, int x, int y) {

        int[][] piece = pentominoe;

        for (int i = 0; i < piece.length; i++) { // loop over x position of pentomino
            for (int j = 0; j < piece[i].length; j++) { // loop over y position of pentomino
                if (piece[i][j] == 1) {
                    // Add the ID of the pentomino to the board if the pentomino occupies this
                    // square
                    gameBoard[x + j][y + i] = 1;
                }
            }
        }
        return gameBoard;
    }

    /**
     * 
     * 
     * @return - an array fileld with 12 unique random pentominoe IDs
     */
    public static int[] createUniqueSeed() {

        int [] myArr = new int [12];
        //Creating new ArrayList of size 9
        //and fill it with number from 1 to 9
        ArrayList<Integer> myArrayList = new ArrayList<>(12);
            for (int i = 0; i < 12; i++) {
                myArrayList.add(i);
                }
        //Using Collections, I shuffle my arrayList
        Collections.shuffle(myArrayList);
        //With for loop and method get() of ArrayList
        //I fill my array
        for(int i = 0; i < myArrayList.size(); i++){
            myArr[i] = myArrayList.get(i);
            }
        
        
        return myArr;
    }

    /**
     * 
     * 
     * @return - an array fileld with random pentominoe IDs
     */
    public static int[] createSeed() {

       
        int[] seed = new int[150];
        for (int i = 0; i < seed.length; i++) {
            Random rand = new Random();
            int random = rand.nextInt(12);
            seed[i] = random;
        }
        return seed;
    }

    /**
     * 
     * @param board - the game board
     * @return - the board in 1s and 0s
     */
    public static int[][] boardToBinary(int[][] board) {
        int[][] binaryBoard = new int[board.length][board[0].length];

        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                if (board[row][col] == -1) {
                    binaryBoard[row][col] = 0;
                } else {
                    binaryBoard[row][col] = 1;
                }

            }
        }

        return binaryBoard;
    }

    /**
     * Will add all the variables together and give the score of the pentominoe
     * position in the board.
     * 
     * @param board      - the game board
     * @param pentominoe - the pentominoe to be added
     * @return - the score of the pentominoe placement
     */
    public static double evaluation(int[][] board) {

        return (height(board) * heightWeight) + (bumpiness(board) * bumpinessWeight)
                + (holes(board) * holesWeight);
    }

    /**
     * 
     * @param board  - the game board
     * @param column - the column index
     * @return
     */
    public static int getHeight(int[][] board, int row) { // returns the difference between the tallest and the
                                                             // shortest column
        int[][] binaryBoard = boardToBinary(board);
        int inverseHeigth = 0;

        for (int column = 0; column < board[0].length; column++) {
            if (binaryBoard[row][column] == 0) {
                inverseHeigth++;
            } else {
                break;
            }
        }

        int height = 15 - inverseHeigth;

        return height;
    }

    /**
     * 
     * @param board - the game board
     * @return
     */
    public static int height(int[][] board) {

        int min = 100;
        int max = 0;

        for (int row = 0; row < board.length; row++) {
            int height = getHeight(board, row);
            min = Math.min(min, height);
            max = Math.max(max, height);
        }
        return (max - min) * -1;
    }

    /**
     * 
     * @param board - the game board
     * @return - the total bumpiness
     */
    public static int bumpiness(int[][] board) {

        int firstCol = getHeight(board, 0);
        int secondCol = getHeight(board, 1);
        int thirdCol = getHeight(board, 2);
        int forthCol = getHeight(board, 3);
        int fifthCol = getHeight(board, 4);

        int firstDifference = Math.abs(firstCol - secondCol);
        int secondDifference = Math.abs(secondCol - thirdCol);
        int thirdDifference = Math.abs(thirdCol - forthCol);
        int forthDifference = Math.abs(forthCol - fifthCol);

        return (firstDifference + secondDifference + thirdDifference + forthDifference) * (-1);
    }

    /**
     * Checks if the pentominoe will clear any number of lines. It returns the
     * number of lines it will
     * delete by adding the pentominoe.
     * 
     * @param board - the game board
     * @return - amount of possible line clears
     */
    public static int willClearLine(int[][] board) {
        int x = 0;

        for (int i = 0; i < board[0].length; i++) {
            if (Tetris.horizontalLineFull(board, i)) {
                x++;
            }
        }

        return x; // EXPERIMENT ABOUT X*X
    }

    /**
     * Counts how many empty squares are left by placing the piece.
     * 
     * @param board - the game board
     * @return - (-1) * no. empty spaces
     */
    public static int holes(int[][] board) {

        int holeCounter = 0;

        int[][] binaryBoard = boardToBinary(board);

        for (int i = 15 - getHeight(board, 0); i < 15; i++) {
            if (binaryBoard[0][i] == 0) {
                holeCounter++;

            }
        }
        for (int i = 15 - getHeight(board, 1); i < 15; i++) {
            if (binaryBoard[1][i] == 0) {
                holeCounter++;
            }
        }
        for (int i = 15 - getHeight(board, 2); i < 15; i++) {
            if (binaryBoard[2][i] == 0) {
                holeCounter++;
            }
        }
        for (int i = 15 - getHeight(board, 3); i < 15; i++) {
            if (binaryBoard[3][i] == 0) {
                holeCounter++;
            }
        }
        for (int i = 15 - getHeight(board, 4); i < 15; i++) {
            if (binaryBoard[4][i] == 0) {
                holeCounter++;
            }
        }

        return holeCounter * -1;
    }

    /**
     * 
     * 
     * @param board
     * @return
     */
    public static int[][] makeCopy(int[][] board) {

        int[][] copyBoard = new int[board.length][board[0].length];

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                copyBoard[i][j] = board[i][j];
            }
        }
        return copyBoard;
    }

    public static int[][] lineClear(int[][] board) {

        for (int row =  0; row < board[0].length; row++) { 

            if (Tetris.horizontalLineFull(board, row)) {
                for (int j = 0; j < board.length; j++) {
                    board[j][row] = -1;
                }

                for (int i = row; i > 0; i--) {
                    for (int j = 0; j < board.length; j++) {
                        board[j][i] = board[j][i - 1];
                    }
                }
            }
        }
        return board;
    }

    /**
     * 
     * 
     * @param board
     */
    public static void play(int[][] board) {

        int[] seed = createSeed();
        int index = 0;

        boolean playing = true;
        int[][] cboard = new int[5][15];
        int[][] bestBoard = new int[5][15];
        int score = 0;
        
        while (playing) {

            index++;
            int randomID = (int) (Math.random()*11);
            playing = false;
            double maxeval = -9999999;
            for (int row = 0; row < board.length; row++) {

                for (int rotation = 0;  rotation < PentominoDatabase.data[seed[index]].length; rotation++) {    
                    cboard = makeCopy(board);

                    if(checkIfFits(cboard, PentominoDatabase.data[seed[index]][rotation], row, 0)) {
                        
                        playing = true;
                        cboard = addPiece(cboard, PentominoDatabase.data[seed[index]][rotation], row, 0);
                        cboard = pieceMoveStraightDown(cboard, PentominoDatabase.data[seed[index]][rotation], row, 0); 
                        ui.setState(cboard);

                        try {
                            Thread.sleep(40);
                        } catch (InterruptedException e) {
                            
                            e.printStackTrace();
                        }

                        // take lineClear as a variable and add it to the evaluation later
                        int lines = willClearLine(cboard);

                        cboard = lineClear(cboard);
                        ui.setState(cboard);

                        if (evaluation(cboard) + lines > maxeval) {
                            maxeval = evaluation(cboard) + lines;
                            bestBoard = makeCopy(cboard);
                            score += lines;
                            //best pentominoe = current pentominoe
                            // memorize the position (the row that it is placed in)

                        }else{        
                            break;
                        }

                    }else{
                        break;
                    }
                    
                }
            }
            board = makeCopy(bestBoard);
            ui.setState(board);
            
            // add the piece with the best rotation and position to the final board and move it straight down
        }
        System.out.println(score);

    }

    public static void initBot(UI a){
        int[][] board = new int[5][15];

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                board[i][j] = -1;
            }
        }

        ui = a;
        Bot bigBoy = new Bot();
        
        for(int i = 0; i < 50; i++){
            bigBoy.play(board);
    }

    }
    public static void main(String[] args) {

        int[][] board = new int[5][15];

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                board[i][j] = -1;
            }
        }

        ui = new UI(5, 15, 50);
        Bot bigBoy = new Bot();
        
        for(int i = 0; i < 50; i++){
            bigBoy.play(board);
    }
}

}
