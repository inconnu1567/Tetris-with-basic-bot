package Implementation;
import java.io.*;

import javax.swing.JOptionPane;
public class HighScore {

    private static String line;

    public static void main(String[]args){
        String file = new String("C:\\Users\\leahi\\Documents\\GitHub\\Tetris-08\\src\\Implementation\\HighScore.csv");
        processFile(file);
        //Call my showScore in here 
    }


    public static String processFile(String file){
        try{
        FileInputStream inputStream = new FileInputStream(file); //reaching the file
        InputStreamReader streamReader = new InputStreamReader(inputStream);  //turning my inputstream into a reader because BufferedReader only accepts this type
        BufferedReader bufferedReader = new BufferedReader(streamReader); //reading the file

        line = bufferedReader.readLine();
        streamReader.close();

        }catch(IOException e){
            e.printStackTrace();}
       String a = line;
       return a;
    }
    

}
    

