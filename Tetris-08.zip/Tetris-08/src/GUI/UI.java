package GUI;
import Implementation.*;
import java.lang.Runnable;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;

/**
 * This class takes care of all the graphics to display a certain state.
 * Initially, you do not need to modify (or event understand) this class in
 * Phase 1. You will learn more about GUIs in Period 2, in the Introduction to
 * Computer Science 2 course.
 */
public class UI extends JPanel implements MouseInputListener, KeyListener, Runnable {
    // private JFrame window;
    private int[][] state;
    private int size;
    public int score = 0;
    JLabel scoreboard = new JLabel(String.valueOf(score), SwingConstants.CENTER);
    JButton button = new JButton();
    Component object = this;
    KeyListener listener = new KeyListener() {

        @Override
        public void keyTyped(KeyEvent e) {
            // TODO Auto-generated method stub
        }

        @Override
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();
            switch (keyCode) {
                /*
                 * case KeyEvent.VK_UP: up.setText("Up: " + Integer.toString(upCount++)); break;
                 */
                case KeyEvent.VK_SPACE:
                    Tetris.Down = true;
                     System.out.println("SPACE BAR");
                    break;
                case KeyEvent.VK_RIGHT:
                    Tetris.Right = true;
                     System.out.println("RIGHT");
                    break;
                case KeyEvent.VK_LEFT:
                    Tetris.Left = true;
                     System.out.println("LEFT");
                    break;
                case KeyEvent.VK_UP:
                    Tetris.Rotate = true;
                     System.out.println("ROTATE");
                    break;
                case KeyEvent.VK_P:
                    Tetris.PauseClicked = !(Tetris.PauseClicked);
                     System.out.println("ROTATE");
                    break;
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            // TODO Auto-generated method stub

        }

    };

    /**
     * Constructor for the GUI. Sets everything up
     * 
     * @param x     x position of the GUI
     * @param y     y position of the GUI
     * @param _size size of the GUI
     */
    public UI(int x, int y, int _size) {

        // ADD A PAUSE OPTION AS WELL
        // ADD HIGHSCORE PLAYER DISPLAY

        

        JButton buttonbot = new JButton("Play bot");
        buttonbot.setBounds(175, 200, 150, 60);
        buttonbot.setHorizontalTextPosition(JButton.CENTER);
        buttonbot.setVerticalTextPosition(JButton.BOTTOM);
        buttonbot.setFont(new Font("Aharoni", Font.PLAIN, 20));
        buttonbot.setForeground(Color.blue);// Change color to ur liking
        buttonbot.setBackground(Color.orange);// Change color to ur liking
        buttonbot.setBorder(BorderFactory.createRaisedBevelBorder());

        buttonbot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
             App.booleanBot = false;
            }
        });


        
        

        JButton button3 = new JButton("Quit");
        button3.setBounds(175, 500, 150, 60);
        button3.setHorizontalTextPosition(JButton.CENTER);
        button3.setVerticalTextPosition(JButton.BOTTOM);
        button3.setFont(new Font("Aharoni", Font.PLAIN, 20));
        button3.setForeground(Color.blue);// Change color to ur liking
        button3.setBackground(Color.orange);// Change color to ur liking
        button3.setBorder(BorderFactory.createRaisedBevelBorder());

        button3.addActionListener(new ActionListener() { // stops the game
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        //Button for the grid
        JButton PlayButton = new JButton("Menu");
        PlayButton.setBounds(175, 200, 150, 60);
        PlayButton.setHorizontalTextPosition(JButton.CENTER);
        PlayButton.setVerticalTextPosition(JButton.BOTTOM);
        PlayButton.setFont(new Font("Aharoni", Font.PLAIN, 20));
        PlayButton.setForeground(Color.blue);// Change color to ur liking
        PlayButton.setBackground(Color.orange);// Change color to ur liking
        PlayButton.setBorder(BorderFactory.createRaisedBevelBorder());

        PlayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Access the game menu
            }
        });

        /*JButton PauseButton = new JButton("Pause / Resume");
        PauseButton.setBounds(70, 300, 220, 60);
        PauseButton.setHorizontalTextPosition(JButton.CENTER);
        PauseButton.setVerticalTextPosition(JButton.BOTTOM);
        PauseButton.setFont(new Font("Aharoni", Font.PLAIN, 20));
        PauseButton.setForeground(Color.blue);// Change color to ur liking
        PauseButton.setBackground(Color.white);// Change color to ur liking
        PauseButton.setBorder(BorderFactory.createRaisedBevelBorder());

        PauseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              Tetris.PauseClicked = !(Tetris.PauseClicked);
            }
        });
*/

        ImageIcon imagee = new ImageIcon("1637641488248.jpg");
        Border borderr = BorderFactory.createLineBorder(new Color(0, 255, 204), 4);// Change color to ur liking

        JLabel label = new JLabel();
        label.setText(" ");
        label.setIcon(imagee);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.TOP);
        label.setBorder(borderr);

        
        ImageIcon image = new ImageIcon("Tetris_Title.jpg"); // creating an image icon
        ImageIcon image2 = new ImageIcon("TetrisT.jpg");
        Border border = BorderFactory.createLineBorder(Color.black);

        // JLabel highscore = new JLabel();

    /*    JLabel nextPieceLabel = new JLabel();
        nextPieceLabel.setBounds(135, 280, 200, 200);*/

        JLabel labelBorder = new JLabel();
        labelBorder.setBounds(103, 198, 104, 64);
        labelBorder.setBorder(border);
        labelBorder.setBackground(Color.black);
        labelBorder.setOpaque(true);

        // 0 will be changed woth the score

        scoreboard.setFont(new Font("Arial", Font.PLAIN, 20));
        scoreboard.setBounds(105, 225, 100, 35);
        scoreboard.setForeground(Color.blue);
        scoreboard.setBackground(Color.white);
        scoreboard.setOpaque(true);
        //scoreboard.add(PauseButton);

        JLabel scoreTextLabel = new JLabel("Score", SwingConstants.CENTER);

        scoreTextLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        scoreTextLabel.setBounds(105, 200, 100, 35);
        scoreTextLabel.setForeground(Color.blue);
        scoreTextLabel.setBackground(Color.white);
        scoreTextLabel.setOpaque(true);

        JLabel label2 = new JLabel();
        label2.setIcon(image2);
        label2.setOpaque(true);
        label2.setVisible(true);
        label2.setBounds(0, -21, 300, 208);
        label2.setBorder(border);

        JLabel scoreText = new JLabel();
        scoreText.setBorder(border);
        scoreText.setPreferredSize(new Dimension(300,780));
        scoreText.setFont(new Font("Serif", Font.PLAIN, 24));
        scoreText.setBackground(Color.magenta);
        scoreText.setVerticalTextPosition(JLabel.TOP);
        scoreText.setHorizontalTextPosition(JLabel.CENTER);
        scoreText.add(scoreboard);
        scoreText.add(label2);
        scoreText.add(scoreTextLabel);
        scoreText.add(labelBorder);
        scoreText.setOpaque(true);
        //scoreText.add(PauseButton);
        scoreText.setVerticalAlignment(JLabel.TOP);
        scoreText.setHorizontalAlignment(JLabel.CENTER);
        scoreText.setBounds(250, 0, 300, 750); // bounds inside the window

        JFrame window = new JFrame("Pentomino");
        window.setTitle("TETRIS");
        window.setPreferredSize(new Dimension(260, 780)); // sets title of frame
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(true);
        object.setPreferredSize(new Dimension(260,780));
        Container pane = window.getContentPane();
        pane.add(scoreText);
        pane.add(object);
        window.addKeyListener(listener);
        window.pack();
        window.setLayout(null);
        window.setVisible(false);

        JButton button = new JButton("Play manually");
        button.setBounds(175, 300, 150, 60);
        button.setHorizontalTextPosition(JButton.CENTER);
        button.setVerticalTextPosition(JButton.BOTTOM);
        button.setFont(new Font("Aharoni", Font.PLAIN, 20));
        button.setForeground(Color.blue);// Change color to ur liking
        button.setBackground(Color.orange);// Change color to ur liking
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton button2 = new JButton("High Score");
        button2.setBounds(175, 400, 150, 60);
        button2.setHorizontalTextPosition(JButton.CENTER);
        button2.setVerticalTextPosition(JButton.BOTTOM);
        button2.setFont(new Font("Aharoni", Font.PLAIN, 20));
        button2.setForeground(Color.blue);// Change color to ur liking
        button2.setBackground(Color.orange);// Change color to ur liking
        button2.setBorder(BorderFactory.createRaisedBevelBorder());

        
        JFrame frame = new JFrame();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setName("Menu"); //?????
        frame.setSize(500, 700);
        frame.setVisible(true);
        frame.getContentPane().setBackground(new Color(221, 204, 255));// Change color to ur liking

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                window.setVisible(true);
                App.checkidkwhat = false;
                frame.setVisible(false);
            }
        });
        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(frame, "The high score is: " + HighScore.processFile("src/Implementation/HighScore.csv"));
            }
        });

        frame.setResizable(false);
        frame.add(button);
        frame.add(button2);
        frame.add(button3);
        frame.add(buttonbot);
        frame.setLayout(new BorderLayout());
        frame.add(label);

        

        size = _size;
        setPreferredSize(new Dimension(x * size, y * size));

        Border borderx = BorderFactory.createLineBorder(Color.black);

        size = _size;
        setPreferredSize(new Dimension(x * size, y * size));

        state = new int[x][y];
        for (int i = 0; i < state.length; i++) {
            for (int j = 0; j < state[i].length; j++) {
                state[i][j] = -1;
            }
        }
    }

    /**
     * This function is called BY THE SYSTEM if required for a new frame, uses the
     * state stored by the UI class.
     */
    public void paintComponent(Graphics g) {
        Graphics2D localGraphics2D = (Graphics2D) g;

        localGraphics2D.setColor(Color.WHITE);
        localGraphics2D.fill(getVisibleRect());

        // draw lines
        localGraphics2D.setColor(Color.GRAY);
        for (int i = 0; i <= state.length; i++) {
            localGraphics2D.drawLine(i * size, 0, i * size, state[0].length * size);
        }
        for (int i = 0; i <= state[0].length; i++) {
            localGraphics2D.drawLine(0, i * size, state.length * size, i * size);
        }

        // draw blocks
        for (int i = 0; i < state.length; i++) {
            for (int j = 0; j < state[0].length; j++) {
                localGraphics2D.setColor(GetColorOfID(state[i][j] - 1));
                localGraphics2D.fill(new Rectangle2D.Double(i * size + 1, j * size + 1, size - 1, size - 1));
            }
        }
    }

    /**
     * Decodes the ID of a pentomino into a color
     * 
     * @param i ID of the pentomino to be colored
     * @return the color to represent the pentomino. It uses the class Color (more
     *         in ICS2 course in Period 2)
     */
    private Color GetColorOfID(int i) {
        if (i == 0) {
            return Color.BLUE;
        } else if (i == 1) {
            return Color.ORANGE;
        } else if (i == 2) {
            return Color.CYAN;
        } else if (i == 3) {
            return Color.GREEN;
        } else if (i == 4) {
            return Color.MAGENTA;
        } else if (i == 5) {
            return Color.PINK;
        } else if (i == 6) {
            return Color.RED;
        } else if (i == 7) {
            return Color.YELLOW;
        } else if (i == 8) {
            return new Color(0, 0, 0);
        } else if (i == 9) {
            return new Color(0, 0, 100);
        } else if (i == 10) {
            return new Color(100, 0, 0);
        } else if (i == 11) {
            return new Color(0, 100, 0);
        } else {
            return Color.white;
        }
    }

    /**
     * This function should be called to update the displayed state (makes a copy)
     * 
     * @param _state information about the new state of the GUI
     */
    public void setState(int[][] _state) {
        for (int i = 0; i < state.length; i++) {
            for (int j = 0; j < state[i].length; j++) {
                state[i][j] = _state[i][j];
            }
        }

        // Tells the system a frame update is required
        repaint();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == button) {

        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public void updateScore() {
        score += 1;
        scoreboard.setText(String.valueOf(score));
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub

    }

}
